
setwd("/home/.samba/homes/jiturra/paper1")
load("model_psim_gini.RData")
load("model_ext_country_small.RData")
library(simr)

fixef(model)['gini_disp'] <- 0.05
n_sim <- 500

p_sim_gini_disp_600_small <- powerCurve(
  model_ext_country, 
  test = simr::fixed("gini_disp", method = "t"),
  along = "country2",
  breaks = 600,
  nsim = n_sim,
  alpha = 0.05,
  progress = TRUE,
  seed = 12345
)

save(p_sim_gini_disp_600_small, file = "p_sim_gini_disp_600_small.RData")
